benchmarkDir = '../data/MOT17Det/train/';
evaluateDetection('c9-train.txt', 'res/MOT17Det/DPM/data', benchmarkDir);