benchmarkGtDir = '../data/2DMOT2015/train/';
[allMets, metsBenchmark] = evaluateTracking('c3-train.txt', 'res/MOT15_3D/data/', benchmarkGtDir, 'MOT15_3D');

