benchmarkGtDir = '../data/2DMOT2015/train/';
[allMets, metsBenchmark] = evaluateTracking('c2-train.txt', 'res/MOT15/data/', benchmarkGtDir, 'MOT15');

