benchmarkDir = '../data/CVPR19Det/train/';
evaluateDetection('c11-train.txt', 'res/CVPR19Det/FRCNN/data', benchmarkDir);
