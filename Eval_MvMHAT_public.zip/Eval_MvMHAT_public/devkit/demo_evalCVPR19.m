benchmarkGtDir = '../data/CVPR19/train/';
[allMets, metsBenchmark] = evaluateTracking('c11-train.txt', 'res/CVPR19/data/', benchmarkGtDir, 'CVPR19');

