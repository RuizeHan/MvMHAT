benchmarkGtDir = '../data/2DMOT16/train/';
[allMets, metsBenchmark] = evaluateTracking('c5-train.txt', 'res/MOT16/data/', benchmarkGtDir, 'MOT16');

